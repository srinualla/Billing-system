-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2020 at 04:44 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `password` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(1, 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `rec_name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `phone_num` varchar(15) NOT NULL,
  `address` varchar(512) NOT NULL,
  `invoice_date` varchar(15) NOT NULL,
  `due_date` varchar(15) NOT NULL,
  `tax` int(20) NOT NULL,
  `total_items` int(20) NOT NULL,
  `total` int(30) NOT NULL,
  `grand_total` int(20) NOT NULL,
  `invoicing_time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `rec_name`, `email`, `phone_num`, `address`, `invoice_date`, `due_date`, `tax`, `total_items`, `total`, `grand_total`, `invoicing_time`) VALUES
(2, 'dsd', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(3, 'srinu12', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(4, '4', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(5, 'srinu12', 'srinualla542@gmail.com', '09866128257', ' ASDFG, Andhra Pradesh', '02-02-2020', '16-02-2020', 4, 18, 6462, 6462, '0000-00-00'),
(6, 'dsd', '', '', ' , ', '', '', 5, 33, 40722, 42758, '0000-00-00'),
(7, 'srinu12', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(8, 'admin', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(9, 'dsd', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(10, 'srinu', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(11, 'dew', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(12, 'admin', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(13, 'srinu', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(14, 'dew', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(15, 'admin', '', '', ' , ', '', '', 0, 0, 0, 0, '0000-00-00'),
(16, 'admin', '', '', ' , ', '', '', 0, 0, 0, 0, '24-02-2020'),
(17, 'admin', '', '', ' , ', '', '', 0, 0, 0, 0, '24-02-2020 09:45:09'),
(18, 'Naga ranthnam', 'srinualla542@gmail.com', '09866128257', ' viskapatanam, Andhra Pradesh', '02-02-2020', '16-02-2020', 4, 8, 6174, 6421, '24-02-2020 11:46:46'),
(22, 'srinu', 'srinualla542@gmail.com', '09866128257', ' viskapatanam, Andhra Pradesh', '', '', 4, 11, 3779, 3930, '24-02-2020 11:51:58'),
(23, 'naga rathnam', 'nagarathnam@gmail.com', '123456789', ' kakinada, Andhra Pradesh', '02-02-2020', '16-02-2020', 4, 12, 7520, 7821, '27-02-2020 09:27:55'),
(24, 'naga rathnam', 'nagarathnam@gmail.com', '123456789', ' kakinada, Andhra Pradesh', '02-02-2020', '16-02-2020', 4, 12, 7520, 7821, '27-02-2020 09:27:57'),
(25, 'naga rathnam', 'nagarathnam@gmail.com', '123456789', ' kakinada, Andhra Pradesh', '', '', 4, 32, 39488, 41068, '27-02-2020 09:30:40'),
(26, 'Gowtham', 'gowthampolimera@gmail.com', '987654321', ' Viskhapatanam, Andhra Pradesh', '27-02-2020', '28-02-2020', 1, 15, 9948, 10047, '27-02-2020 05:23:42'),
(27, 'gow', '', '', ' , ', '', '', 3, 6, 1001328, 1031368, '27-02-2020 05:26:01'),
(28, 'dew', 'srinualla542@gmail.com', '09866128257', ' asd, Andhra Pradesh', '08-06-2020', '08-06-2020', 0, 64, 1120, 1120, '07-06-2020 04:29:16'),
(29, 'dew', 'srinualla542@gmail.com', '09866128257', ' d, Andhra Pradesh', '07-06-2020', '22-06-2020', 0, 323, 969, 969, '07-06-2020 04:30:19');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `product_id` int(11) NOT NULL,
  `inv_id` int(11) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `line_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`product_id`, `inv_id`, `product_name`, `price`, `qty`, `line_total`) VALUES
(1, 1, 'asdss', 1234, 33, 0),
(2, 1, 'asdss', 1234, 33, 0),
(3, 2, 'srinu', 1234, 33, 0),
(4, 0, 'asdss', 1234, 33, 0),
(5, 4, 'asdss', 1234, 33, 0),
(6, 4, 'asd', 1234, 3, 3702),
(7, 4, 'sds', 184, 15, 2760),
(8, 6, 'asdss', 1234, 33, 40722),
(9, 4, 'asdss', 1234, 33, 0),
(10, 8, 'asdss', 1234, 33, 0),
(11, 8, 'asdss', 1234, 33, 0),
(12, 10, 'asd', 1234, 33, 0),
(13, 11, 'asd', 1234, 33, 0),
(14, 12, 'asdss', 1234, 33, 0),
(15, 13, 'asdss', 1234, 33, 0),
(16, 14, 'asdss', 1234, 33, 0),
(17, 14, 'asdss', 1234, 33, 0),
(18, 15, 'asdss', 1234, 33, 0),
(19, 16, 'asdss', 1234, 33, 0),
(20, 17, 'asdss', 1234, 33, 0),
(21, 17, 'asdss', 1234, 33, 0),
(22, 17, 'asdss', 1234, 33, 0),
(23, 18, 'perfume-1', 123, 3, 369),
(24, 18, 'perfume-2', 1303, 3, 3909),
(25, 18, 'perfume-3', 948, 2, 1896),
(29, 22, 'pe-1', 123, 3, 369),
(30, 22, 'pe-2', 355, 5, 1775),
(31, 22, 'pe-3', 545, 3, 1635),
(32, 0, 'per-1', 1234, 3, 3702),
(33, 0, 'per-2', 324, 2, 648),
(34, 0, 'per-3', 450, 3, 1350),
(35, 0, 'per-1', 455, 4, 1820),
(36, 24, 'per-1', 1234, 3, 3702),
(37, 24, 'per-2', 324, 2, 648),
(38, 24, 'per-3', 450, 3, 1350),
(39, 24, 'per-1', 455, 4, 1820),
(40, 25, 'per-1', 1234, 32, 39488),
(41, 25, 'asdss', 1234, 33, 0),
(42, 26, 'Aga-1', 123, 3, 369),
(43, 26, 'Aga-2', 322, 3, 966),
(44, 26, 'Aga-3', 957, 9, 8613),
(45, 27, 'sds', 333333, 3, 999999),
(46, 27, 'jj', 443, 3, 1329),
(47, 29, '21', 32, 32, 1024),
(48, 29, '32', 3, 32, 96),
(49, 30, 'ds', 3, 323, 969);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
