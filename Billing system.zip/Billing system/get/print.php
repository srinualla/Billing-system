<?php 
session_start();
require_once("../includes/dbcon.php");
if(!isset($_SESSION['name'])) {
	header('Location: ../login/index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Naga ranthnam | Print</title>
    <script src="libs/jquery.js"></script>
	<script src="libs/font-awesome-4.7.0/kitfontawesome.js"></script>
	<link rel="stylesheet" href="libs/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/print.css?v=1.1" media="all">
</head>
<body>
<button onclick="CallPrint('print');">Print</button>
    <div id="print">
        <?php
        $inv_id = $_GET['id'];
        $select = "SELECT * FROM invoice INNER JOIN items ON invoice.id = items.inv_id";
        $query = mysqli_query($con,$select);
        ?>
        <div class="logo">
            <img src="../images/large-white.png" alt="">
            <div class="address">
                <div class="content">
                    <h2>From address :</h2>
                    <p>Naga rathnam Perfumes</p>
                    <p>Kakinada, Andhra Pradesh,</p>
                    <p>99666 44333, 99666 44333</p>
                    <p>nagarathnam@gmail.com</p>
                </div>
            </div>
        </div>
        <div class="rec-info">
            <div class="head">
                <h1>INVOICE</h1>
                <?php
                    $t = time();
                    $month = date("M - Y",$t);
                    echo "<h3>".$month."</h3>";
                ?>
            </div>
            <div class="to-address">
                <div class="date-info">
                    <?php
                        $sel_rec = "SELECT * FROM invoice WHERE id = '$inv_id'";
                        $q_rec = mysqli_query($con,$sel_rec);
                        $row_1 = mysqli_fetch_assoc($q_rec);
                    ?>
                    <h5>Serial number: <p><?php echo $row_1['id'];?></p></h5>
                    <h5>Issue date: <p><?php echo $row_1['invoice_date'];?></p></h5>
                    <h5>Due date: <p><?php echo $row_1['due_date'];?></p></h5>
                </div>
                <div class="to-details">
                    <h2>Invoice to:</h2>
                    <?php 
                        $html_code = "";
                        $html_code .= "<p>".$row_1['rec_name']."</p>";
                        $html_code .= "<p>".$row_1['phone_num']."</p>";
                        $html_code .= "<p>".$row_1['email']."</p>";
                        $html_code .= "<p>".$row_1['address']."</p>";
                        echo $html_code;     
                    ?>
                </div>
            </div>
        </div>

        <table class="order-list">
            <thead>
                <tr>
                    <th>Id</th>
                    <!-- <th>Invoice Id</th> -->
                    <!-- <th>Name</th> -->
                    <!-- <th>Product Id</th> -->
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Line total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $counter=1;
                    while($row = mysqli_fetch_assoc($query)){
                        if($row['inv_id']==$inv_id){
                            $html = '';
                            $html .= '<tr>';
                            $html .= '<td>'.$counter++.'</td>';
                            // $html .= '<td>'.$row['inv_id'].'</td>';
                            // $html .= '<td>'.$row['rec_name'].'</td>';
                            // $html .= '<td>'.$row['product_id'].'</td>';
                            $html .= '<td>'.$row['product_name'].'</td>';
                            $html .= '<td>'.$row['price'].'</td>';
                            $html .= '<td>'.$row['qty'].'</td>';
                            $html .= '<td class="line-total">'.$row['line_total'].'</td>';
                            $html .= '</tr>';
                            echo $html; 
                        }
                    }
                ?>
            </tbody>
        </table>
        <ul>
            <li>
                <h4>Total items</h4>
                <span>:</span>
                <p>
                    <?php
                        echo $row_1['total_items'];
                    ?>
                </p>
            </li>
            <li>
                <h4>Total</h4> 
                <psan>:</psan>
                <p>
                    <?php
                        echo $row_1['total'];
                    ?>
                </p>
            </li>
            <li>
                <h4>Tax </h4>
                <span>:</span>
                <p>
                    <?php
                        echo $row_1['tax'];
                    ?>
                </p>
            </li>
            <li>
                <h4>Grand total </h4>
                <span>:</span>
                <p>
                    <?php
                        echo $row_1['grand_total'];
                    ?>
                </p>
            </li>
        </ul>
    <div class="signatuer">
        <h2>Signature:<p>____________</p></h2>
    </div>
    <footer>
        <p>nagarathnam@gmail.com,</p>
        <p>99666 44333, 99666 44333,</p>
        <p>Naga rathnam Perfumes,</p>
        <p>Kakinada, Andhra Pradesh</p>
    </footer>
    </div>
<script>
function CallPrint(strid) {
    var prtContent = document.getElementById(strid);
    var WinPrint = window.open('', '', 'left=0,top=0,width=900px,height=600px,toolbar=1,scrollbars=1,status=0');
    WinPrint.document.write(prtContent.innerHTML);
    WinPrint.document.close();
    WinPrint.focus();
    WinPrint.print();
    WinPrint.close();
    prtContent.innerHTML = "";
}
</script>
</body>
</html>