<?php
    include "../includes/dbcon.php";
    $select = "SELECT * FROM invoice"; 
    $query= mysqli_query($con,$select); 

    if($query){
        while($row = mysqli_fetch_assoc($query)){
            $html = "";
            $html .= "<tr>"; 
            $html .= "<td>".$row['id']."</td>";
            $html .= "<td>".$row['rec_name']."</td>";
            // $html .= "<td>".$row['email']."</td>";
            $html .= "<td>".$row['phone_num']."</td>";
            // $html .= "<td>".$row['address']."</td>";
            $html .= "<td>".$row['invoice_date']."</td>";
            $html .= "<td>".$row['due_date']."</td>";
            $html .= "<td>".$row['tax']."</td>";
            $html .= "<td>".$row['total_items']."</td>";
            $html .= "<td>".$row['total']."</td>";
            $html .= "<td>".$row['grand_total']."</td>";
            $html .= "<td><a href='get/edit.php?id=".$row['id']."'><i class='fa fa-edit'></i> <p>Edit</p></a></td>";
            $html .= "<td><a href='get/view.php?id=".$row['id']."'><i class='fa fa-eye'></i><p>View</p> </a></td>";
            $html .= "<td><a href='get/delete.php?id=".$row['id']."'><i class='fa fa-trash'></i><p>Delete</p></a></td>";
            $html .= "</tr>"; 
            echo $html;
        }
    }

?>
