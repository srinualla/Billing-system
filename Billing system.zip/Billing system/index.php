<?php
session_start();
require_once("includes/dbcon.php");
if(!isset($_SESSION['name'])) {
	header('Location: login/index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Naga Rathnam Perfumes</title>
	<script src="libs/jquery.js"></script>
	<script src="libs/jquery-ui-1.12.1/jquery-ui.min.js"></script>
	<script src="libs/font-awesome-4.7.0/kitfontawesome.js"></script>
	<link rel="stylesheet" href="libs/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/sample.css?v=1.3">
	<link rel="stylesheet" href="css/calendar.css" media="screen">
	<script>
		$( function() {
			$( ".datepicker,.datepicker2" ).datepicker({dateFormat: "dd-mm-yy"});
		} );
	</script>
</head>
<body>
	<div class="container">
		<div class="sidebar">
			<h1 class="admin">Admin</h1>
			<ul id="tab">
				<li class="li" id="dashboard">
					<i class="fas fa-home"></i>
					<a>Dashboard</a>
				</li>
				<li class="li" id="invoice">
					<i class="fas fa-file-invoice"></i>
					<a>Invoice</a>
				</li>
				<li class="li" id="billRecord">
					<i class="fas fa-database"></i>
					<a>Bill Record</a>			
				</li>
				<li class="li" id="salesReport">
					<i class="fas fa-hand-holding-usd"></i>
					<a>Sales Report</a>
				</li>
				<li class="li" id="totalPayments">
					<i class="fas fa-credit-card"></i>
					<a>Total Payments</a>
				</li>
			</ul>
		</div>
		<div class="title">
			<div class="img">
				<img src="images/large.png" alt="">
			</div>
			<div class="out">
				<a class="logout btn" href="login/logout.php" id="logout">Logout</a>
			</div>
		</div>
		<div  class="content">
			<div class="data" id="dashboardTab">
				<h3>Sales report</h3>
				<div class="container">
					<div class="totalSales">
						<i class="fas fa-hand-holding-usd"></i>
						<span>
							<h3>Total sales</h3>
							<div class = "count">36153</div>
						</span>
					</div>
					<div class="totalPayments">
						<i class="fas fa-credit-card"></i>
						<span>
							<h3>Total Payments</h3>
							<div class="count">1283929</div>	
						</span>
					</div>
					<div class="todaySales">
						<i class="fas fa-hand-holding-usd"></i>
						<span>
							<h3>Today Sales</h3>
							<div class = "count">36153</div>
						</span>
					</div>
					<div class="todayPayments">
						<i class="fas fa-credit-card"></i>
						<span>
							<h3>Today Payments</h3>
							<div class="count">1283929</div>	
						</span>
					</div>
				</div>
			</div>
			<div class="data" id="invoiceTab">
				<?php include "includes/invoice.inc.php";?>
			</div>
			<div class="data" id="billRecordTab">
				<?php include "includes/billrecord.inc.php";?>
			</div>
			<div class="data" id="salesReportTab"></div>
			<div class="data" id="totalPaymentsTab"></div>
		</div>
	</div>

<script>
	$('.data').hide();
	$("#invoiceTab").show();
	$("#tab li").click(function (e) { 
		e.preventDefault();
		var t = $(this).attr('id');
		$('#tab li').css("background","transparent");
		$('.data').hide();
		$('#'+t).css("background","#B6C3EB");
		$('#'+ t + 'Tab').fadeIn(300);
	});
</script>
<script src="js/shortcut.js"></script>
<script src="js/addItems.js?v=1.1"></script>
<script src="js/script.js?v=1.6"></script>
<script src="js/search.js"></script>
<script src="js/bill-list.js"></script>
</body>
</html>
