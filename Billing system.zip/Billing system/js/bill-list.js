$.ajax({
    type: "GET",
    url: "get/bill_records.php",
    success: function (response) {
        $("#bills-list tbody").append(response);
    }
});