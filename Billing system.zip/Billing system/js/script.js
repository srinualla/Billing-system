$(".submit").click((event)=>{
	event.preventDefault();

	var product_name = [];
	var price = [];
	var qty = [];
	var linetotal_arr = [];

	$('.product_name').each(function(){
	product_name.push($(this).val());
	});
	$('.price').each(function(){
	price.push($(this).val());
	});
	$('.qty').each(function(){
	qty.push($(this).val());
	});
	$('.linetotal').each(function(){
	linetotal_arr.push($(this).val());
	});
	$.ajax({
		type: "post",
		url: "invoice.php",
		data:{
			recName: $("#recName").val(),
			email: $("#email").val(),
			phoneNum: $("#phoneNum").val(),
			state: $("#state").val(),
			district: $("#district").val(),
			invoiceDate: $("#invoiceDate").val(),
			dueDate: $("#dueDate").val(),
			tax: $("#tax").val(),
			total_items: $("#total_items").val(),
			total: $("#total").val(),
			grand_total: $("#grand_total").val()
		},
		success: function (response) {
			var dataResult = JSON.parse(response);
			if(dataResult.statusCode==200){
				$("#success").show();
				$('#success').html('Data added successfully !');
			}
			else if(dataResult.statusCode==201){
				$("#success").show();
				$('#success').html('Error occured !');
			}else{
				$("#success").show();
				$('#success').html('Nothing happen');
			}	
		}
	});
	$.ajax({
		type: "POST",
		url: "list.php",
		data: {
			product_name: product_name,
			price: price,
			qty: qty,
			linetotal: linetotal_arr
		},
		success: function (result){
			$(location).attr('href', ("get/print.php?id="+result));
		}
	});
	setTimeout(() => {
		$("#success").fadeOut();
	}, 2000);
})
