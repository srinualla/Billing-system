$(document).ready(function () {
    var counter = 1;

    $("#add").on("click", function () {
		addItem();
    });

	shortcut.add("ctrl+space",function () { 
		addItem();
	 })

	function addItem(){

        counter++;

        var newRow = $("<tr>");
        var cols = "";

        cols += '<td>'+ counter +'';
        cols += '<td><input type="text" class="product_name" placeholder="Product name" name="product' + counter + '"/></td>';
        cols += '<td><input type="number" placeholder="Price" class="price" name="price' + counter + '"/></td>';
        // cols += '<td><input type="number" placeholder="Tax" name="tax' + counter + '"/></td>'
        cols += '<td><input type="number" placeholder="Quantity" class="qty" name="qty' + counter + '"/></td>';
        cols += '<td><input type="text" class="linetotal" name="linetotal' + counter + '" readonly="readonly"/></td>';
        cols += '<td><a id="deleteRow"><i class="fa fa-close"></i></a></td></tr>';

        newRow.append(cols);

        $("table#invoice-list").append(newRow);

	}
    $("table#invoice-list").on("change", 'input[name^="price"], input[name^="qty"],input[name^="tax"]', function (event) {
        calculateRow($(this).closest("tr"));
        calculateTotalItems()
        calculateTotal();
        calculateGrandTotal();
    });

    $("table#invoice-list").on("click", "#deleteRow", function (event) {
        $(this).closest("tr").remove();
		calculateTotalItems()
		calculateTotal()
		calculateGrandTotal()
    });

    // $(".print").click(function (e) { 
    //     e.preventDefault();
    //     window.print();
    // });

});
function calculateRow(row) {
    // GST Amount = (Original Cost x GST%)/100
    // Net Price = Original Cost + GST Amount
    var price = row.find('input[name^="price"]').val();
    var qty = row.find('input[name^="qty"]').val();
    // var tax = row.find('input[name^="tax"]').val();
    // var taxAmount = (parseInt(price) * parseInt(tax))/100; 
    // var netPrice = parseInt(taxAmout) + parseInt(price);
    row.find('input[name^="linetotal"]').val(((price * qty)));
}

function calculateTotal() {
    var Totale = 0;
    $("table#invoice-list").find('input[name^="linetotal"]').each(function () {
        Totale += parseInt($(this).val());   
	});
    $("#total").val(Totale);
}
function calculateGrandTotal() {
    var totale = parseInt($("#total").val());
    var tax = parseInt($("#tax").val());
    var grandTotale = totale * tax / 100;;   
    var grandTotale_price = totale + grandTotale;
    $("#grand_total").val(grandTotale_price);
}

function calculateTotalItems(){
	var totalItems=0;
    $("table#invoice-list").find('input[name^="qty"]').each(function () {
        totalItems += parseInt($(this).val());   
    });	
    $("#total_items").val(totalItems);
}
