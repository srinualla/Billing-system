<?php
session_start();
require_once("includes/dbcon.php");
if(!isset($_SESSION['name'])) {
	header('Location: login/index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Naga Rathnam Perfumes</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css?v=1.1">
    <!-- <link rel="stylesheet" href="css/style.css?v=1.1"> -->
	<script src="jquery.js"></script>
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<!-- <link rel="stylesheet" href="https://code.jquery.com//resources/demos/style.css"> -->
	<script>
	$( function() {
		$( "#datepicker,#datepicker2" ).datepicker();
	} );
	</script>
</head>
<body>

	<div class="container">
		<div class="title">
			<h1>Naga Rathnam Perfumes</h1>
		</div>
		<ul class="sidebar" id="tab">
			<li class="li" id="dashboard">
				<i class="fas fa-home"></i>
				<p>Dashboard</p>
			</li>
			<li class="li" id="invoice">
				<i class="fas fa-file-invoice"></i>
				<p>Invoice</p>
			</li>
			<li class="li" id="billRecord">
				<i class="fas fa-database"></i>
				<p>Bill Record</p>			
			</li>
			<li class="li" id="salesReport">
				<i class="fas fa-hand-holding-usd"></i>
				<p>Sales Report</p>
			</li>
			<li class="li" id="totalPayments">
				<i class="fas fa-credit-card"></i>
				<p>Total Payments</p>
			</li>
			<li class="li logout">
			<form action="index.php" method="post">
				<input type="submit" value="Logout" name="logout">
			</form>
			</li>
		</ul>

		<ul class="content">		
			<li class="data" id="dashboardTab">
			<div class="totalSales">
					<i class="fas fa-hand-holding-usd"></i>
					<span>
						<h3>Total sales</h3>
						<div class = "count">36153</div>
					</span>
				</div>
				<div class="totalPayments">
					<i class="fas fa-credit-card"></i>
					<span>
						<h3>Total Payments</h3>
						<div class="count">1283929</div>	
					</span>
				</div>
				<div class="todaySales">
					<i class="fas fa-hand-holding-usd"></i>
					<span>
						<h3>Today Sales</h3>
						<div class = "count">36153</div>
					</span>
				</div>
				<div class="todayPayments">
					<i class="fas fa-credit-card"></i>
					<span>
						<h3>Today Payments</h3>
						<div class="count">1283929</div>	
					</span>
				</div>
			</li>
			<li class="data" id="invoiceTab">
				<h1>Create New Invoice</h1>
				<form action="invoice.php" method="post">
					<div class="row-1">
						<div class="cont">
							<p><i class="fas fa-user"></i> Receiver information</p>
							<div class="receiverInfo block">
								<div class="inpFeild">
									<input type="text" name="recName" placeholder="Receiver name" id="custName" required>
									<input type="email" name="email" placeholder="E-mail">
									<input type="tel" name="phoneNum" id="phoneNum" placeholder="Phone Number" required>
								</div>
							</div>
						</div>
						<div class="cont">
							<p> <i class="fas fa-address-book"></i> Address</p>
							<div class="address block">
								<div class="inpFeild">
									<input type="text" name="state" placeholder="State" id="state" value="Andhra Pradesh" required>
									<input type="text" name="district" placeholder="District" required>
									<input type="text" name="line" placeholder="Address line" required>
								</div>
							</div>
						</div>
					<!-- <div class="cald">
						<label for="invoiceDate">
							<input type="text" class="date" id="datepicker" name="invoiceDate" placeholder="Invoice date" value="" required>
							<i class="fas fa-calendar"></i>
						</label>
						<label for="dueDate">
							<input type="text" class="date" id="datepicker2" name="dueDate" placeholder="Due date" value="" required>
						</label>
					</div> -->
				</div>
				<!-- <div class="row-2">
					<button class="print">Print  <i class="fas fa-print"></i></button>
					<button class="cancel cancelBill">Cancel <i class="fa fa-close"></i></button>
				</div> -->
				<!-- <div class="row-3">
				<table class="order-list">
					<thead>
						<tr><td>Id</td><td>Product</td><td>Price</td><td>Qty</td><td>Total</td></tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td><input type="text" name="product" placeholder="Product name" /></td>
							<td><input type="text" name="price"  placeholder="Price"/></td>
							<td><input type="text" placeholder="Quantity" name="qty"/></td>
							<td><input type="text" name="linetotal" readonly="readonly" /></td>
							<td><a class="cancel" id="deleteRow"><i class="fa fa-close"></i></a></td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="5" style="text-align: center;">
								<a id="add">+add item</a>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								Total items: <p id="totalItems"></p>
							</td>
							<td colspan="2">
								Grand Total: <p id="grandtotal"></p>
							</td>
						</tr>
						<tr>
							<td colspan="0">
								<input type="submit" value="Create" name="createInvoice" class="createInvoice">
							</td>
						</tr>
					</tfoot>
				</table>
				</div>
			</form>
			</li>
			<li class="data" id="billRecordTab"></li>
			<li class="data" id="salesReportTab"></li>
			<li class="data" id="totalPaymentsTab"></li>
		</ul>
	</div> -->
<script>
	$('.data').hide();
	$("#invoiceTab").show();
	$("#tab li").click(function (e) { 
		e.preventDefault();
		var t = $(this).attr('id');
		$('#tab li').css("background","#35188e");
		$('#tab li').css("color","#ffffff");
		$('.data').hide();
		$('#'+ t + 'Tab').fadeIn(300);
		$('#'+t+'').css("background","#ffffff");
		$('#'+t+'').css("color","#35188e");
	});
</script>
<script src="js/addItem.js?v=1.1"></script>
</body>
</html>
<?php

if(isset($_POST['logout'])){
	session_destroy();
	header('Location: login/index.php');
}
