<?php
session_start();
include "includes/dbcon.php";
$productName = $_POST['product_name'];
$price = $_POST['price'];
$qty = $_POST['qty'];
$lineTotal = $_POST['linetotal'];
$ide = $_SESSION['naga_rathnam_inv_id'];
$inv_id = $ide+1;
for($count=0;$count<count($productName);$count++){
    $pN = $productName[$count];
    $pr = $price[$count];
    $q = $qty[$count];
    $lt = $lineTotal[$count];
    $id = $inv_id; 
    $insert_item = "INSERT INTO items VALUES ('','$id','$pN','$pr','$q','$lt')";
    $query_item = mysqli_query($con,$insert_item);
}
echo $inv_id;
