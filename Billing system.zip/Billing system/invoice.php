<?php
session_start();
include "includes/dbcon.php";
$recName = $_POST['recName'];  
$email = $_POST['email'];
$phoneNume = $_POST['phoneNum'];

$state = $_POST['state'];
$district = $_POST['district'];

$invoiceDate = $_POST['invoiceDate'];
$dueDate = $_POST['dueDate'];

$tax = $_POST['tax'];
$total_items = $_POST['total_items'];
$total = $_POST['total'];
$grand_total = $_POST['grand_total'];
date_default_timezone_set('Asia/Kolkata');
$t = time();
$time = date("d-m-Y h:i:s",$t);
if(!empty($recName)){
  $insert = "INSERT INTO invoice VALUES ('','$recName','$email','$phoneNume',' $district, $state','$invoiceDate','$dueDate','$tax','$total_items','$total','$grand_total','$time')";
  $query = mysqli_query($con,$insert);
  // $inv_id =0;
  session_destroy('naga_rathnam_inv_id');
  $_SESSION['naga_rathnam_inv_id'] =  mysqli_insert_id($con);
  if ($query) {
    echo json_encode(array("statusCode"=>200));
  } 
  else {
    echo json_encode(array("statusCode"=>201));
  }
}else{
  echo "fill the feild";
}