<?php
    $con = mysqli_connect("localhost","root","","naga rathnam perfumes");
?>