<form id="form" method="post">
	<h1>Create New Invoice</h1>
	<h2 id="success" class="success"></h2>
	<div class="row-2">
		<div class="receiverInfo block">
			<p><i class="fas fa-user"></i> Receiver information</p>
			<div class="inpFeild">
				<input type="text" id="recName" placeholder="Receiver name">
				<input type="email" id="email" placeholder="E-mail">
				<input type="tel" id="phoneNum" placeholder="Phone Number">
			</div>
		</div>
		<div class="address block">
			<p> <i class="fas fa-address-book"></i> Address</p>
			<div class="inpFeild">
				<input type="text" id="state" placeholder="State" >
				<input type="text" id="district" placeholder="District">
				<input type="text" id="line" placeholder="Address line">
			</div>
		</div>
		<div class="cald block">
			<p><i class="fas fa-calendar"></i> Date</p>
			<div class="inpFeild">
				<input type="text" class="date datepicker" id="invoiceDate" placeholder="Invoice date" readonly>
				<input type="text" class="date datepicker2" id="dueDate" placeholder="Due date" readonly>
			</div>
		</div>
	</div>
		<table id="invoice-list" class="order-list">
			<thead>
				<tr><th>Id</th><th>Product</th><th>Price</th><th>Qty</th><th>Total</th></tr>
			</thead>
			<tbody></tbody>
			<tfoot>
				<tr>
					<td  colspan="1" style="text-align: center;padding:0px">
						<a class="btn" id="add"> <p>+add item</p></a>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						GST: <input type="number" id="tax" id="tax" value="0"/>
					</td>
					<td colspan="2">
						Total: <input type="text" id="total" readonly="readonly" value="0"/>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						Total items: <input type="text" id="total_items" readonly="readonly" id="totalItems" value="0"/>
					</td>
					<td colspan="2">
						Grand Total: <input type="text" id="grand_total" readonly="readonly" id="grandTotal" value="0"/>
					</td>
					<td colspan="4" class="row-5">
						<button class="btn cancel cancelBill">Cancel <i class="fas fa-close"></i></button>
						<button id="create" class="btn submit create">Create <i class="fas fa-plus"></i></button>
						<!-- <button class="btn print submit" id="create">Print  <i class="fas fa-print"></i></button> -->
					</td>
				</tr>
				<!-- <tr>
				</tr> -->
		</tfoot>
	</table>
</form>
