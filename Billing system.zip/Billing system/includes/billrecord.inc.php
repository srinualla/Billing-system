<table id="bills-list" class="order-list">
    <thead>
        <tr>
            <th>id</th>
            <th>Name</th>
            <!-- <th>Email</th> -->
            <th>Phone number</th>
            <!-- <th>Address</th> -->
            <th>Invoice date</th>
            <th>Payment date</th>
            <th>Tax</th>
            <th>Total items</th>
            <th>Total</th>
            <th>Grand total</th>
            <!-- <th>Time</th> -->
            <th>Edit</th>
            <th>Delete</th>
            <th>View</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
    <thead>
        <tr>
            <th>id</th>
            <th>Name</th>
            <!-- <th>Email</th> -->
            <th>Phone number</th>
            <!-- <th>Address</th> -->
            <th>Invoice date</th>
            <th>Payment date</th>
            <th>Tax</th>
            <th>Total items</th>
            <th>Total</th>
            <th>Grand total</th>
            <!-- <th>Time</th> -->
            <th>Edit</th>
            <th>Delete</th>
            <th>View</th>
        </tr>
    </thead>
</table>
