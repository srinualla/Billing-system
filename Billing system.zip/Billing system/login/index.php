<?php
session_start();
require_once("../includes/dbcon.php");

if(!isset($_SESSION['name'])){
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $password = $_POST['password']; 
        $select = "SELECT * FROM `admin` WHERE `name` = '$name' AND `password`= '$password'";
        $sel_que = mysqli_query($con,$select); 

        if(mysqli_num_rows($sel_que) > 0){
            echo "login";   
            $_SESSION['name'] = $name; 
            header("Location: ../index.php");
        }else{
            header("Location: login.php");
        }
        mysqli_close($con);
    }
}else{
    header("Location: ../index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Naga Rathnam Perfumes</title>
    <link rel="stylesheet" href="../css/main.css?v=1.1">
    <script src="../libs/jquery.js"></script>
	<script src="../libs/font-awesome-4.7.0/kitfontawesome.js"></script>
	<link rel="stylesheet" href="../libs/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="../images/large-white.png" alt="">
        </div>
    </header>
	<form action="index.php" method="post">
        <div class="h1">
            <h1>Login</h1>
        </div>
        <label for="name">
            <i class='fa fa-user'></i>
            <input type="text" name="name" placeholder="Name">
        </label>
    
        <label for="password">
            <i class="fa fa-lock"></i>
            <input type="password" name="password" placeholder="Password">
        </label>
        <button type="submit" name="submit">Login</button>
    </form>
<?php require_once("../includes/footer.php");?>
